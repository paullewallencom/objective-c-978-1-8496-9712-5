//
//  ViewController.h
//  Storyboard
//
//  Created by Gibson Tang on 30/6/13.
//  Copyright (c) 2013 Gibson Tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@end
