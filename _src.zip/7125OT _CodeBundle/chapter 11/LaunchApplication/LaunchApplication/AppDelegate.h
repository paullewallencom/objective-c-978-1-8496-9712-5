//
//  AppDelegate.h
//  LaunchApplication
//
//  Created by Gibson Tang on 2/11/14.
//  Copyright (c) 2014 Gibson Tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

