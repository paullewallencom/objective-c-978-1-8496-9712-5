// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var name = "Gib"

var sum = 0
for i in 0...10
{
    sum += i
}

sum