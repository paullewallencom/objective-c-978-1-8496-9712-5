//
//  ViewController.h
//  MemoryManagement
//
//  Created by Gibson Tang on 13/4/14.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
